 // p2 갤러리 데이터 셋팅하기 ////
const p2g_linfo = {
    
        "이미지" : ["p2g1","p2g2","p2g3","p2g4","p2g5","p2g6","p2g7","p2g8","p2g9","p2g10",],

        "제목" : 
        ["NASA's Juno Mission Spies Vortices Near Jupiter's North Pole","Ganymede - Galileo",
        "Pioneer 10 - Ganymede",
        "Ganymede From Voyager 1",
        "Family Portrait of the Jovian System",
        "Ganymede - New Horizons",
        "Jupiter's Moons: Family Portrait",
        "Close-up of Dark Side of Jupiter Moon Ganymede",
        "Ganymede in Infrared (Juno)",
        "Juno's Ganymede Close-up"],

        "내용":[
            "As NASA's Juno mission completed its 43rd close flyby of Jupiter on July 5, 2022, its JunoCam captured this striking view of vortices.",
            "A natural color view of Ganymede from the Galileo spacecraft during its first encounter with the satellite.",
            "NASA's Pioneer 10 was the first spacecraft to obtain close-up images of Jupiter, and three of its largest moons: Ganymede, Callisto, and Europa.",
            "This picture of Ganymede, Jupiter's largest satellite, was taken by Voyager 1 on March 5, 1979.",
            "This composite image includes Jupiter with its Great Red Spot. and from top to bottom: Io, Europa, Ganymede, and Callisto.",
            "This is New Horizons' best image of Ganymede, Jupiter's largest moon, taken with the spacecraft's Long Range Reconnaissance Imager (LORRI) camera at 10:01 Universal Time on Feb. 27, 2007, from a range of 2.2 million miles (3.5 million kilometers).",
            "This montage shows the best views of Jupiter's four large and diverse \"Galilean\" satellites as seen by the Long Range Reconnaissance Imager (LORRI) on the New Horizons spacecraft during its flyby of Jupiter in late February 2007",
            "This image of the dark side of Ganymede was taken by NASA's Juno spacecraft during its June 7, 2021, flyby of the icy moon.",
            "This infrared view of Ganymede was obtained by the Jovian Infrared Auroral Mapper (JIRAM) instrument on NASA's Juno spacecraft during its July 20th, 2021, flyby.",
            "This image of Jupiter's moon Ganymede was taken by NASA's Juno spacecraft during its June 7, 2021, flyby of the icy moon.",
        ]
}